﻿using System;

namespace String_interpolation
{
    class Program
    {
        static void Main(string[] args)
        {
            //Deze opdracht heb ik al toegepast overal waar mogelijk in het vorige hoofdstuk.
        }
    }
}
