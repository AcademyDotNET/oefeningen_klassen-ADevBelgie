﻿using System;

namespace ASCII_Art
{
    class Program
    {
        static void Main(string[] args)
        {
            string myname = @"   _____            __   .__                    
  /  _  \ _______ _/  |_ |  |__   __ __ _______ 
 /  /_\  \\_  __ \\   __\|  |  \ |  |  \\_  __ \
/    |    \|  | \/ |  |  |   Y  \|  |  / |  | \/
\____|__  /|__|    |__|  |___|  /|____/  |__|   
        \/                    \/                ";
            Console.WriteLine(myname);
        }
    }
}
