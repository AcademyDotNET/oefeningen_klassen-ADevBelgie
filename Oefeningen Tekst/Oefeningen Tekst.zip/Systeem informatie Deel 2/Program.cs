﻿using System;
using System.IO;
namespace Systeem_informatie_Deel_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Over welke drive wil je informatie?");
            int inputDrive = (Convert.ToInt32(Console.ReadLine()) - 1); //Ik heb maar 1 drive dus ik weet niet of dit gaat werken.
            Console.Clear();

            Console.WriteLine("Drive information:\n");

            long cdriveinbytes = DriveInfo.GetDrives()[inputDrive].AvailableFreeSpace;
            long totalsize = DriveInfo.GetDrives()[inputDrive].TotalSize;
            
            Console.WriteLine($"Free space on drive in bytes: {cdriveinbytes} in GB: {cdriveinbytes/ 1000000000}");
            Console.WriteLine($"Free total space on drive in bytes: {totalsize} in GB: {totalsize / 1000000000}");
        }
    }
}
