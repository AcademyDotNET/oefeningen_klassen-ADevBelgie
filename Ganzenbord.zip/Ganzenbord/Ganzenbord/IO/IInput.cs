﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ganzenbord
{
    interface IInput
    {
        public string ReadLine();
        public int ReadLineNumber();
    }
}
