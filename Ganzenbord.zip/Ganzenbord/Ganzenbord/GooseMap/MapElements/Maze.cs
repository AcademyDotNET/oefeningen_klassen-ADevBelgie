﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ganzenbord
{
    class Maze : MapElement
    {
        public Maze(Spaces currentSpace) : base(currentSpace)
        {
        }
    }
}
