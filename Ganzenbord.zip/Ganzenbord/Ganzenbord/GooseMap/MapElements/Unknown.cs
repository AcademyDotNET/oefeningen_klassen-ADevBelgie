﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ganzenbord
{
    class Unknown : MapElement
    {
        public Unknown(Spaces currentSpace) : base(currentSpace)
        {
        }
    }
}
