﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ganzenbord
{
    class End : MapElement
    {
        public End(Spaces currentSpace) : base(currentSpace)
        {
        }
    }
}
