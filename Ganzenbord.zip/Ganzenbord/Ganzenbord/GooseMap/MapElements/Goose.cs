﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ganzenbord
{
    class Goose : MapElement
    {
        public Goose(Spaces currentSpace) : base(currentSpace)
        {
        }
    }
}
