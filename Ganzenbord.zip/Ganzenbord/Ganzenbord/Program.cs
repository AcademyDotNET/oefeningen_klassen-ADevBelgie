﻿using System;

namespace Ganzenbord
{
    class Program
    {
        static void Main(string[] args)
        {
            GooseManager GM = new GooseManager();
            GM.Start();
        }
    }
}
