﻿using System;

namespace Kleurcode_weerstand_naar_ohm
{
    class Program
    {
        static void Main(string[] args)
        {
            //deze opdracht in vorige reeks oef gemaakt.
        }
    }
}
