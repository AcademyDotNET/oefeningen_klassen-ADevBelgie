﻿using System;

namespace Intro_methode
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Intro methode");
            //skip
        }
    }
}
