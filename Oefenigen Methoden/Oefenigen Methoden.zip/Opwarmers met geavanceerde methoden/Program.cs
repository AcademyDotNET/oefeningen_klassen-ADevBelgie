﻿using System;

namespace Opwarmers_met_geavanceerde_methoden
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Opwarmers met geavanceerde methoden\n");

            //miss volgende keer
        }
    }
}
